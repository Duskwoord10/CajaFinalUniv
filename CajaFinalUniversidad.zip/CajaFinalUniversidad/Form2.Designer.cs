﻿namespace CajaFinalUniversidad
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            this.label1 = new System.Windows.Forms.Label();
            this.Asignaturas1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbCosto = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ComboCredito = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AgregarBTN = new System.Windows.Forms.Button();
            this.SalirBTN = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Codigo = new System.Windows.Forms.ColumnHeader();
            this.Asignatura = new System.Windows.Forms.ColumnHeader();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.EliminarAsignatura = new System.Windows.Forms.Button();
            this.Asignaturas1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Maiandra GD", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(238, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Caja Universidad INMESA";
            // 
            // Asignaturas1
            // 
            this.Asignaturas1.AccessibleDescription = "";
            this.Asignaturas1.AccessibleName = "Asignaturas";
            this.Asignaturas1.Controls.Add(this.textBox1);
            this.Asignaturas1.Controls.Add(this.lbCosto);
            this.Asignaturas1.Controls.Add(this.label8);
            this.Asignaturas1.Controls.Add(this.ComboCredito);
            this.Asignaturas1.Controls.Add(this.label5);
            this.Asignaturas1.Controls.Add(this.label7);
            this.Asignaturas1.Controls.Add(this.label4);
            this.Asignaturas1.Location = new System.Drawing.Point(35, 108);
            this.Asignaturas1.Name = "Asignaturas1";
            this.Asignaturas1.Size = new System.Drawing.Size(879, 148);
            this.Asignaturas1.TabIndex = 1;
            this.Asignaturas1.TabStop = false;
            this.Asignaturas1.Text = "groupBox1";
            this.Asignaturas1.Enter += new System.EventHandler(this.Asignaturas1_Enter);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(12, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(204, 23);
            this.textBox1.TabIndex = 10;
            // 
            // lbCosto
            // 
            this.lbCosto.AutoSize = true;
            this.lbCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbCosto.Location = new System.Drawing.Point(637, 54);
            this.lbCosto.Name = "lbCosto";
            this.lbCosto.Size = new System.Drawing.Size(93, 20);
            this.lbCosto.TabIndex = 9;
            this.lbCosto.Text = "LblCarrera";
            this.lbCosto.Click += new System.EventHandler(this.lbCosto_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(615, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Carrera";
            // 
            // ComboCredito
            // 
            this.ComboCredito.Enabled = false;
            this.ComboCredito.Location = new System.Drawing.Point(289, 51);
            this.ComboCredito.Name = "ComboCredito";
            this.ComboCredito.Size = new System.Drawing.Size(204, 23);
            this.ComboCredito.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(353, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Id";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(25, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 20);
            this.label7.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(12, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nombre Estudiante";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(713, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Fecha Actual :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(818, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "lblFecha";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // AgregarBTN
            // 
            this.AgregarBTN.BackColor = System.Drawing.Color.Tomato;
            this.AgregarBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AgregarBTN.Location = new System.Drawing.Point(355, 280);
            this.AgregarBTN.Name = "AgregarBTN";
            this.AgregarBTN.Size = new System.Drawing.Size(134, 43);
            this.AgregarBTN.TabIndex = 7;
            this.AgregarBTN.Text = "Pagar ";
            this.AgregarBTN.UseVisualStyleBackColor = false;
            // 
            // SalirBTN
            // 
            this.SalirBTN.BackColor = System.Drawing.Color.Tomato;
            this.SalirBTN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SalirBTN.Location = new System.Drawing.Point(842, 531);
            this.SalirBTN.Name = "SalirBTN";
            this.SalirBTN.Size = new System.Drawing.Size(134, 43);
            this.SalirBTN.TabIndex = 8;
            this.SalirBTN.Text = "Salir";
            this.SalirBTN.UseVisualStyleBackColor = false;
            this.SalirBTN.Click += new System.EventHandler(this.SalirBTN_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Codigo,
            this.Asignatura,
            this.columnHeader1,
            this.columnHeader2});
            listViewGroup1.Header = "ListViewGroup";
            listViewGroup1.Name = "listViewGroup1";
            this.listView1.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1});
            this.listView1.Location = new System.Drawing.Point(35, 370);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(879, 155);
            this.listView1.TabIndex = 9;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // Codigo
            // 
            this.Codigo.Text = "Codigo";
            this.Codigo.Width = 100;
            // 
            // Asignatura
            // 
            this.Asignatura.Text = "Asignatura";
            this.Asignatura.Width = 300;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Creditos";
            this.columnHeader1.Width = 300;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Profesor";
            this.columnHeader2.Width = 200;
            // 
            // EliminarAsignatura
            // 
            this.EliminarAsignatura.BackColor = System.Drawing.Color.Tomato;
            this.EliminarAsignatura.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.EliminarAsignatura.Location = new System.Drawing.Point(517, 280);
            this.EliminarAsignatura.Name = "EliminarAsignatura";
            this.EliminarAsignatura.Size = new System.Drawing.Size(134, 43);
            this.EliminarAsignatura.TabIndex = 10;
            this.EliminarAsignatura.Text = "Eliminar Asignatura";
            this.EliminarAsignatura.UseVisualStyleBackColor = false;
            this.EliminarAsignatura.Click += new System.EventHandler(this.EliminarAsignatura_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 652);
            this.Controls.Add(this.EliminarAsignatura);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.SalirBTN);
            this.Controls.Add(this.AgregarBTN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Asignaturas1);
            this.Controls.Add(this.label1);
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "S";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Asignaturas1.ResumeLayout(false);
            this.Asignaturas1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private GroupBox Asignaturas1;
        private TextBox ComboCredito;
        private Label label5;
        private Label label7;
        private Label label4;
        private Label label2;
        private Label label3;
        private Button AgregarBTN;
        private Button SalirBTN;
        private Label lbCosto;
        private Label label8;
        private ListView listView1;
        private TextBox textBox1;
        private ColumnHeader Codigo;
        private ColumnHeader Asignatura;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private Button EliminarAsignatura;
    }
}