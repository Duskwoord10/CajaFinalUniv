﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace CajaFinalUniversidad
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Asignaturas1_Enter(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

            // Configurar el estilo del borde del formulario para que no sea redimensionable
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Borde fijo, no redimensionable

            // Establecer el tamaño máximo del formulario (opcional)
            this.MaximumSize = new System.Drawing.Size(1000, 1000); // Tamaño máximo del formulario (ancho, alto)

            // Mostrar solo la fecha actual en el formato "dd/MM/yyyy"
            label3.Text = DateTime.Now.ToString("dd/MM/yyyy");
            lbCosto.Text = (0).ToString("c");

            // Mostrar solo la hora actual en el formato de 24 horas "HH:mm:ss"
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lbCosto_Click(object sender, EventArgs e)
        {

        }

        private void SalirBTN_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void EliminarAsignatura_Click(object sender, EventArgs e)
        {


            // Verificar si hay un ítem seleccionado en el ListView
            if (listView1.SelectedItems.Count > 0)
            {
                // Recorrer todos los ítems seleccionados en el ListView
                foreach (ListViewItem item in listView1.SelectedItems)
                {
                    // Eliminar el ítem seleccionado del ListView
                    listView1.Items.Remove(item);
                }
            }
            else
            {
                // Mostrar un mensaje si no hay ningún ítem seleccionado
                MessageBox.Show("Por favor, selecciona una Asignatura a eliminar.", "Eliminar Ítem", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }
    }
}
